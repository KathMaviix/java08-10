package main;


public class TesteExcecoes {
    public static void main(String[] args) {
        // Instanciando as exceções
        MinhaExcecao1 excecao1 = new MinhaExcecao1("Exceção 1");
        MinhaExcecao2 excecao2 = new MinhaExcecao2("Exceção 2");
 
        // Tratando a primeira exceção
        try {
            excecao1.gerarExcecao();
        } catch (MinhaExcecao1 e) {
            System.out.println("Capturada: " + e.getMessage());
        }
 
        // Tratando a segunda exceção
        try {
            excecao2.gerarExcecao();
        } catch (MinhaExcecao2 e) {
            System.out.println("Capturada: " + e.getMessage());
        }
    }
}
